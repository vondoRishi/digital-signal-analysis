package testSwing;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class jFreeImplementation extends JFrame implements ActionListener {
	
	private JPanel contentPane;
	private double[] xData;
	private double[] yData;
	private String mtitle;
	private String xLabel;
	private String yLabel;
	private JButton btnClose;
	private JButton btnExtract;
	private final  JFileChooser fc = new JFileChooser();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					jFreeImplementation frame = new jFreeImplementation();
//					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	private void jFreeImplementation() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 796, 521);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = getChartPanel();
		panel.setBounds(12, 12, 770, 435);
		contentPane.add(panel);
		
		btnClose = new JButton("Close");
		btnClose.addActionListener(this);
		btnClose.setBounds(668, 459, 114, 24);
		contentPane.add(btnClose);
		
		btnExtract = new JButton("Extract Values");
		btnExtract.addActionListener(this);
		btnExtract.setBounds(489, 459, 155, 24);
		
		contentPane.add(btnExtract);
		setVisible(true);
	}

	private JPanel getChartPanel() {
		 XYSeries series1 = new XYSeries("");
	        for (int i = 0; i < yData.length; i++) {
				
				series1.add(xData[i],yData[i]);
			}
	        XYSeriesCollection dataset = new XYSeriesCollection();
	    	dataset.addSeries(series1);
	    	
	    	 JFreeChart jfreechart = ChartFactory.createXYLineChart(mtitle, xLabel, null, dataset,PlotOrientation.VERTICAL, true, true, false);
	         XYPlot xyplot = (XYPlot)jfreechart.getPlot();
	         xyplot.setDomainPannable(true);
	         xyplot.setRangePannable(true);
	         jfreechart.removeLegend();
	         
	         JPanel jpanel = new ChartPanel(jfreechart);
		return jpanel;
	}

	public jFreeImplementation(double[] xData, double[] yData,
			String title, String xLabel, String yLabel) {
		this.xData = xData;
		this.yData = yData;
		this.mtitle = title;
		this.xLabel = xLabel;
		this.yLabel = yLabel;
		jFreeImplementation();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnClose){
			this.dispose();
		}else if(e.getSource()==btnExtract){
			saveToFile();
		}
		
	}
	
	private void saveToFile() {
		int returnVal = fc.showSaveDialog(this);
		//fc.setApproveButtonText();
		//fc.setOpaque(true);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            try {
				BufferedWriter brWr = new BufferedWriter(new FileWriter(file));
				brWr.write(xLabel+","+yLabel+System.getProperty("line.separator"));
				for (int i = 0; i < yData.length; i++) {
					brWr.write(xData[i]+","+yData[i]+System.getProperty("line.separator"));
				}
				brWr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//log.error(e);
			}
        } else {
          //  log.append("Open command cancelled by user." + newline);
        }


	}
}

