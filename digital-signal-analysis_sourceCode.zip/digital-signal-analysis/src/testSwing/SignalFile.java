package testSwing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Rishi Das Roy
 *
 * @Organization Institute Of Genomics & Integrative Biology
 */
public class SignalFile {
	private File mFile;

	private int mStartLine;

	private int mEndLine = Integer.MAX_VALUE;

	private int mColNum;

	private String mColSep;

	private boolean mIsERG;

	public static final String COMMA = "Comma";
	public static final String TAB = "Tab";
	public static final String SPACE = "Space";

	public SignalFile(File file) {
		super();
		mFile = file;
	}

	public void setStartLine(int pStartLine) {
		this.mStartLine = pStartLine;

	}

	public void setColSep(String pColSep) {
		if(pColSep.equals(COMMA)){
			this.mColSep = ",";
		}else if(pColSep.equals(TAB)){
			this.mColSep = "\t";
		}else if(pColSep.equals(SPACE)){
			this.mColSep = " ";
		}

	}

	public void setEndLine(int pEndLine) {
		this.mEndLine = pEndLine;

	}

	public void setColNum(int pColNum) {
		this.mColNum = pColNum;

	}

	public double[] getTimeSeries() throws IOException{
		List<String> listOfValues = getListFromCSV(mFile, mColNum, mStartLine, mEndLine, mColSep);
		double[] series = new double[listOfValues.size()];
		int i = 0;
		try {
			if(mIsERG){
				processERGseries(listOfValues);
			}

			for (; i < listOfValues.size(); i++) {
				series[i] = Double.parseDouble(listOfValues.get(i));
			}
			return series;
		} catch (NumberFormatException e) {
			return null;
		} catch (Exception e) {
			return null;
		}

	}

	private void processERGseries(List<String> listOfValues) throws Exception {
		for (int j = 1; j < listOfValues.size(); j++) {
			String string = listOfValues.get(j);
			if(string.startsWith("**")){
				if(j<3){
					String upper = getFromUpper(j+2,listOfValues);
					if(upper==null){
						throw new Exception("No data from upper side where index="+j);
					}
					listOfValues.set(j, upper);
				}else{
					String lower = getFromLower(j-2,listOfValues);
					String upper = getFromUpper(j+2,listOfValues);
					upper = upper != null ? upper : lower;
					Float f = (Float.parseFloat(upper) + Float.parseFloat(lower))/2;
					listOfValues.set(j, f.toString());
				}
			}
		}

	}

	private  String getFromLower(int j, List<String> columValues) {
		String data = null;


		if( !columValues.get(j).startsWith("**")){
			data = columValues.get(j);
		}else if ( !columValues.get(j+1).startsWith("**")) {
			data = columValues.get(j+1);
		}
		return data;
	}

	private  String getFromUpper(int j, List<String> columValues) {
		String data = null;


			if(j<columValues.size() && !columValues.get(j).startsWith("**")){
				data = columValues.get(j);
			}else if (j-1 <columValues.size() && !columValues.get(j-1).startsWith("**")) {
				data = columValues.get(j-1);
			}
		return data;

	}

	public  List<String> getListFromCSV(File file, int column, int from, int to, String pDelimiter) throws IOException {
		List<String> listOfValues = new ArrayList<String>();

		BufferedReader in = new BufferedReader(new FileReader(file));
		String str;
		int i=1;
		while ((str = in.readLine()) != null) {
			if(i>=from && i <= to){
				str = str.split(pDelimiter)[column-1];
				listOfValues.add(str.trim());
			}
			i++;
		}
		in.close();


	return listOfValues;
	}

	public void setERG(boolean pIsERG) {
		this.mIsERG = pIsERG;

	}

	public String[] getERGHeader() throws IOException {
		BufferedReader in = new BufferedReader(new FileReader(mFile));
		String str;
		String [] header = null;
		int i=1;
		while ((str = in.readLine()) != null) {
			if(i==12){
				header = str.split("\t");
				break;
			}
			i++;
		}
		in.close();


	return header;

	}

	public String getFileName() {
		// TODO Auto-generated method stub
		return mFile.getName();
	}
}
